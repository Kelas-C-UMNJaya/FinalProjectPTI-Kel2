# 7-Days Student
## {Be DominanT}

### Link Video Penjelasan Game
https://drive.google.com/file/d/1uUB2fx17HcUfhTqocgmvVLLQwbn4ZC9V/view?usp=sharing

### Anggota
- Areta Escalonia. C/[aescalonia](https://github.com/aescalonia) (00000057872)
- Jefer Setiawan/[Ajeppp](https://github.com/Ajeppp) (00000059297)
- Nataniel Tambayung/[natanieltam](https://github.com/natanieltam) (00000057617)
- Steve Christian. Y. P/[stevgamz](https://github.com/stevgamz) (00000058797)

### Cara bermain dan aturan

Selamat datang di permainan 7-Days Student! 
Ini adalah Sebuah Game yang dibuat berdasarkan kehidupan Mahasiswa Baru selama kuliah di UMN selama 7 hari pertama. 
Sebelum bermain berikut adalah cara bermain dan beberapa peraturan yang harus dibaca terlebih dahulu. 
Peraturan: 
- Pilih karakter yang mau dipakai, masukan nama anda, dan pilih jurusan.
- Klik "Start" untuk memulai permainan.
- Anda akan masuk ke menu game, di awal permainan semua progress bar akan terisi 50%, kecuali progress bar belajar yang dimulai dari 0%.
- Permainan akan di mulai dari hari minggu pada pukul 00:00.
- Ketika anda menekan "Makan" maka progress bar makan akan tambah. Tidur dan main akan berkurang.
- Ketika anda menekan "Belajar" maka progress bar belajar akan tambah. Makan, main dan tidur akan berkurang.
- Ketika anda menekan "Main" maka progress bar main akan bertambah. Makan dan tidur akan berkurang.  
- Ketika anda menekan "Tidur" maka progress bar tidur akan tambah. Makan dan tidur akan berkurang.
- Ketika anda menekan tombol "Kampus" maka anda akan berpindah ke kampus dan hanya bisa melakukan aktifitas yang bisa dilakukan di kampus.
- Ketika anda menekan tombol "Cafe" maka anda akan berpindah ke cafe dan hanya bisa melakukan aktifitas yang bisa dilakukan di cafe.
- Ketika anda menekan tombol "Hiling" maka anda akan berpindah ke pantai dan hanya bisa melakukan aktifitas yang bisa dilakukan di pantai.
- Jika anda idle progress bar akan berkurang, kecuali progress bar belajar.
- Ketika anda mencapai 7 hari permainan akan selesai dan Permainan akan menampilkan hasil evaluasi selama seminggu.