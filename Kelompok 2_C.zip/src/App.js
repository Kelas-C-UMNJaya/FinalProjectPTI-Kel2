import React, { useState } from "react"
import AvatarChakra from "./Page/AvatarChakra";

function App() {

  return (
    <div>
      <AvatarChakra />
    </div>
  )
};

export default App;
